-- MySQL dump 10.13  Distrib 5.6.32-78.1, for Linux (x86_64)
--
-- Host: localhost    Database: choicema_accounts
-- ------------------------------------------------------
-- Server version	5.6.32-78.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `account`
--

DROP TABLE IF EXISTS `account`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `account` (
  `accountid` int(11) NOT NULL AUTO_INCREMENT,
  `accountname` varchar(50) NOT NULL,
  `amount` double NOT NULL,
  `chartid` varchar(30) NOT NULL,
  PRIMARY KEY (`accountid`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `account`
--

LOCK TABLES `account` WRITE;
/*!40000 ALTER TABLE `account` DISABLE KEYS */;
INSERT INTO `account` (`accountid`, `accountname`, `amount`, `chartid`) VALUES (1,'A/c Receivable ',7844266.390000004,'1'),(2,'Income',8096266.390000001,'5'),(3,'Security Deposit',-100,'2'),(6,'Petty Cash',251900,'1'),(7,'Director Expense',0,'4'),(8,'capital',0,'3');
/*!40000 ALTER TABLE `account` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `adjustment`
--

DROP TABLE IF EXISTS `adjustment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `adjustment` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date NOT NULL,
  `chartaccount` varchar(50) NOT NULL,
  `MainAccount` varchar(50) NOT NULL,
  `subaccount` varchar(50) NOT NULL,
  `amount` double NOT NULL,
  `chartaccount1` varchar(50) NOT NULL,
  `MainAccount1` varchar(50) NOT NULL,
  `subaccount1` varchar(50) NOT NULL,
  `amount1` double NOT NULL,
  `description` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `adjustment`
--

LOCK TABLES `adjustment` WRITE;
/*!40000 ALTER TABLE `adjustment` DISABLE KEYS */;
INSERT INTO `adjustment` (`id`, `date`, `chartaccount`, `MainAccount`, `subaccount`, `amount`, `chartaccount1`, `MainAccount1`, `subaccount1`, `amount1`, `description`) VALUES (1,'2018-08-09','Assets','A/c Receivable ','M.Ali',100000000,'Assets','Security Deposit','M.Ali',100000000,'testing\r\n'),(2,'2018-08-09','Liabilities','Security Deposit','M.Ali',100000000,'Liabilities','A/c Receivable ','M.Ali',100000000,'testing');
/*!40000 ALTER TABLE `adjustment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `by`
--

DROP TABLE IF EXISTS `by`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `by` (
  `accountname` varchar(50) NOT NULL,
  `accountid` int(11) NOT NULL,
  `chartid` int(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `by`
--

LOCK TABLES `by` WRITE;
/*!40000 ALTER TABLE `by` DISABLE KEYS */;
INSERT INTO `by` (`accountname`, `accountid`, `chartid`) VALUES ('',0,1);
/*!40000 ALTER TABLE `by` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `chartaccount`
--

DROP TABLE IF EXISTS `chartaccount`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `chartaccount` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `accountname` varchar(50) NOT NULL,
  `amount` double NOT NULL,
  `chartid` varchar(30) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `chartaccount`
--

LOCK TABLES `chartaccount` WRITE;
/*!40000 ALTER TABLE `chartaccount` DISABLE KEYS */;
INSERT INTO `chartaccount` (`id`, `accountname`, `amount`, `chartid`) VALUES (1,'Assets',-252000,'1'),(2,'Liabilities',-100,'2'),(3,'Expense',0,'4'),(4,'Revenue',0,'5'),(5,'Owners Equity',0,'3');
/*!40000 ALTER TABLE `chartaccount` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `invoice`
--

DROP TABLE IF EXISTS `invoice`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `invoice` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `Date` date NOT NULL,
  `Bill` varchar(50) NOT NULL,
  `Customer` varchar(50) NOT NULL,
  `subaccount` varchar(50) NOT NULL,
  `subaccount1` varchar(50) NOT NULL,
  `subaccount2` varchar(50) NOT NULL,
  `subaccount3` varchar(50) NOT NULL,
  `subaccount4` varchar(50) NOT NULL,
  `subaccount5` varchar(50) NOT NULL,
  `amountvalue` double NOT NULL,
  `amountvalue1` double NOT NULL,
  `amountvalue2` double NOT NULL,
  `amountvalue3` double NOT NULL,
  `amountvalue4` double NOT NULL,
  `amountvalue5` double NOT NULL,
  `Description` varchar(500) NOT NULL,
  `Total` double NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=127 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `invoice`
--

LOCK TABLES `invoice` WRITE;
/*!40000 ALTER TABLE `invoice` DISABLE KEYS */;
INSERT INTO `invoice` (`id`, `Date`, `Bill`, `Customer`, `subaccount`, `subaccount1`, `subaccount2`, `subaccount3`, `subaccount4`, `subaccount5`, `amountvalue`, `amountvalue1`, `amountvalue2`, `amountvalue3`, `amountvalue4`, `amountvalue5`, `Description`, `Total`) VALUES (1,'2018-08-01','A/c Receivable ','Abdul Samad Jagda-29','Rent','','','','','',5000,1000,0,0,0,0,'for the garbage scattered all over the streets which is spoiling our environment and also creating problem in passing through the road.',6000),(2,'2018-08-01','A/c Receivable ','Abdul Samad Jagda-28','Rent','','','','','',82460,0,0,0,0,0,'for the garbage scattered all over the streets which is spoiling our environment and also creating problem in passing through the road.',82460),(3,'2018-08-01','A/c Receivable ','Ilyas Scrap','Penalty','','','','','',50000,0,0,0,0,0,'for the garbage scattered all over the streets which is spoiling our environment and also creating problem in passing through the road.',50000),(4,'2018-08-06','A/c Receivable ','Agha Muhammad-2','Deposits','Rent','','','','',25000,25000,0,0,0,0,'for the garbage scattered all over the streets which is spoiling our environment and also creating problem in passing through the road.',50000),(5,'2018-08-01','A/c Receivable ','Ilyas Scrap','Penalty','','','','','',150000,0,0,0,0,0,'for the garbage scattered all over the streets which is spoiling our environment and also creating problem in passing through the road.',150000),(6,'2018-08-08','A/c Receivable ','Adeel Infinty-6','Rent','','','','','',45000,0,0,0,0,0,'for the garbage scattered all over the streets which is spoiling our environment and also creating problem in passing through the road.',45000),(7,'2018-08-08','A/c Receivable ','Najibullah-7','','','','','','',60000,0,0,0,0,0,'for the garbage scattered all over the streets which is spoiling our environment and also creating problem in passing through the road.',60000),(8,'2018-08-08','A/c Receivable ','Kashif Mehmood-42','','','','','','',145000,0,0,0,0,0,'for the garbage scattered all over the streets which is spoiling our environment and also creating problem in passing through the road.',145000),(9,'2018-08-08','A/c Receivable ','Zarah Traders','Rent','Electric Charges','Service Charges','Balance','','',57750,4000,2210,60,0,0,'for the garbage scattered all over the streets which is spoiling our environment and also creating problem in passing through the road.',64020),(10,'2018-08-08','A/c Receivable ','Najibullah-7','Rent','','','','','',60000,0,0,0,0,0,'for the garbage scattered all over the streets which is spoiling our environment and also creating problem in passing through the road.',60000),(11,'2018-08-08','A/c Receivable ','M.Younus','Penalty','','','','','',10000,0,0,0,0,0,'for the garbage scattered all over the streets which is spoiling our environment and also creating problem in passing through the road.',10000),(13,'2018-08-09','A/c Receivable ','New Century ','Rent','Electric Charges','','','','',57000,5000,0,0,0,0,'Rent for the month of August 2018.',62000),(14,'2018-06-27','A/c Receivable ','Meraj Ali','Deposits','','','','','',150000,0,0,0,0,0,'Deposit for New Godown.',150000),(15,'2018-08-01','A/c Receivable ','Hamza Traders','Rent','Service Charges','Balance','','','',42400,2500,3000,0,0,0,'Rent for the month of August 2018.',47900),(16,'2018-08-01','A/c Receivable ','Hamza Traders','Rent','Service Charges','Balance','','','',41976,2500,3000,0,0,0,'Rent for the month of August 2018.',47476),(17,'2018-08-01','A/c Receivable ','Hamza Traders','Rent','Service Charges','Balance','','','',42000,2500,3000,0,0,0,'Rent for the month of August 2018.\r\n',47500),(18,'2018-08-15','A/c Receivable ','M.Younus','Deposits','','','','','',26000,0,0,0,0,0,'Deposit for new godown.',26000),(19,'2018-08-01','A/c Receivable ','Millac Food','Rent','Service Charges','','','','',48584,1000,0,0,0,0,'Rent for the month of July 2018.\r\n',49584),(20,'2018-08-01','A/c Receivable ','Infinity ','Rent','','','','','',45000,0,0,0,0,0,'Rent for the month of July 2018',45000),(21,'2018-08-28','A/c Receivable ','Agha Muhammad-2','Rent','','','','','',25000,0,0,0,0,0,'Rent for the month of September 2018, Due date is 10th of each month Rs.1000 will be charged as penalty after the due date.',25000),(22,'2018-08-28','A/c Receivable ','M.Shahid Hussain','Rent','','','','','',37000,0,0,0,0,0,'Rent for the month of September 2018, Due date is 10th of each month Rs.1000 will be charged as penalty after the due date.',37000),(23,'2018-08-28','A/c Receivable ','Khurram Abdul Ghaffaar','Rent','','','','','',44800,0,0,0,0,0,'Rent for the month of September 2018, Due date is 10th of each month Rs.1000 will be charged as penalty after the due date.',44800),(24,'2018-08-28','A/c Receivable ','Akhlaque Ahmed','Rent','Electric Charges','','','','',52500,4000,0,0,0,0,'Rent for the month of September 2018, Due date is 10th of each month Rs.1000 will be charged as penalty after the due date.',56500),(25,'2018-08-28','A/c Receivable ','Adeel Infinty-6','Rent','Balance','','','','',45000,5000,0,0,0,0,'Rent for the month of September 2018, Due date is 10th of each month Rs.1000 will be charged as penalty after the due date.',50000),(26,'2018-08-28','A/c Receivable ','Najibullah-7','Rent','','','','','',60000,0,0,0,0,0,'Rent for the month of September 2018, Due date is 10th of each month Rs.1000 will be charged as penalty after the due date.',60000),(27,'2018-08-28','A/c Receivable ','Abdul Ghaffar','Rent','','','','','',110000,0,0,0,0,0,'Rent for the month of September 2018, Due date is 10th of each month Rs.1000 will be charged as penalty after the due date.',110000),(28,'2018-08-28','A/c Receivable ','Ahmed Karam Ali','Rent','Electric Charges','Service Charges','Extra Space','','',29630,5000,1222,1792,0,0,'Rent for the month of September 2018, Due date is 10th of each month Rs.1000 will be charged as penalty after the due date.',37644),(30,'2018-08-28','A/c Receivable ','Haris Ismail','Rent','','','','','',21850,0,0,0,0,0,'Rent for the month of September 2018, Due date is 10th of each month Rs.1000 will be charged as penalty after the due date.',21850),(31,'2018-08-28','A/c Receivable ','Zarah Traders','Rent','Electric Charges','Service Charges','Balance','','',57850,4000,2210,60,0,0,'Rent for the month of September 2018, Due date is 10th of each month Rs.1000 will be charged as penalty after the due date.',64120),(33,'2018-08-28','A/c Receivable ','Data Enterprises','Rent','Balance','','','','',39166,3,0,0,0,0,'Rent for the month of September 2018, Due date is 10th of each month Rs.1000 will be charged as penalty after the due date.',39169),(34,'2018-08-28','A/c Receivable ','Shahzad Ismail','Rent','Electric Charges','Service Charges','Parking','','',32625,7000,2000,6000,0,0,'Rent for the month of September 2018, Due date is 10th of each month Rs.1000 will be charged as penalty after the due date.',47625),(35,'2018-08-28','A/c Receivable ','Waheed Memon','Rent','Electric Charges','Service Charges','Balance','','',193597,8000,8500,95485,0,0,'Rent for the month of September 2018, Due date is 10th of each month Rs.1000 will be charged as penalty after the due date.',305582),(36,'2018-08-28','A/c Receivable ','Mustafa Traders','Rent','Electric Charges','','','','',400000,15000,0,0,0,0,'Rent for the month of September 2018, Due date is 10th of each month Rs.1000 will be charged as penalty after the due date.',415000),(37,'2018-08-28','A/c Receivable ','Abdul Razzak','Rent','Service Charges','','','','',123000,2000,0,0,0,0,'Rent for the month of September 2018, Due date is 10th of each month Rs.1000 will be charged as penalty after the due date.',125000),(38,'2018-08-28','A/c Receivable ','Orkila Pakistan','Rent','','','','','',57564.64,0,0,0,0,0,'Rent for the month of September 2018, Due date is 10th of each month Rs.1000 will be charged as penalty after the due date.',57564.64),(39,'2018-08-28','A/c Receivable ','Safwan Sajid','Rent','','','','','',28000,0,0,0,0,0,'Rent for the month of September 2018, Due date is 10th of each month Rs.1000 will be charged as penalty after the due date.',28000),(40,'2018-08-28','A/c Receivable ','Shakeel Ahmed  ','Rent','Electric Charges','','','','',65178,4000,0,0,0,0,'Rent for the month of September 2018, Due date is 10th of each month Rs.1000 will be charged as penalty after the due date.',69178),(41,'2018-08-28','A/c Receivable ','Shaikh  Afaq','Rent','Service Charges','Balance','','','',65952,3000,63,0,0,0,'Rent for the month of September 2018, Due date is 10th of each month Rs.1000 will be charged as penalty after the due date.',69015),(42,'2018-08-28','A/c Receivable ','Shaikh  Afaq','Rent','Balance','','','','',82460,140,0,0,0,0,'Rent for the month of September 2018, Due date is 10th of each month Rs.1000 will be charged as penalty after the due date.',82600),(43,'2018-08-28','A/c Receivable ','Abdul Samad Jagda-28','Rent','Electric Charges','','','','',82460,3000,0,0,0,0,'Rent for the month of September 2018, Due date is 10th of each month Rs.1000 will be charged as penalty after the due date.',85460),(44,'2018-08-28','A/c Receivable ','Abdul Samad Jagda-29','Rent','','','','','',4000,0,0,0,0,0,'Rent for the month of September 2018, Due date is 10th of each month Rs.1000 will be charged as penalty after the due date.',4000),(45,'2018-08-28','A/c Receivable ','Abdul Samad Jagda-31','Rent','','','','','',10000,0,0,0,0,0,'Rent for the month of September 2018, Due date is 10th of each month Rs.1000 will be charged as penalty after the due date.',10000),(46,'2018-08-28','A/c Receivable ','New Century ','Rent','Electric Charges','','','','',57000,5000,0,0,0,0,'Rent for the month of September 2018, Due date is 10th of each month Rs.1000 will be charged as penalty after the due date.',62000),(47,'2018-08-28','A/c Receivable ','Sindh Trading Corp','Rent','Others','Tax','','','',64448,3515,-3222,0,0,0,'Rent for the month of September 2018, Due date is 10th of each month Rs.1000 will be charged as penalty after the due date.',64741),(48,'2018-08-28','A/c Receivable ','Kamran Shadman','Rent','Electric Charges','','','','',46000,4000,0,0,0,0,'Rent for the month of September 2018, Due date is 10th of each month Rs.1000 will be charged as penalty after the due date.',50000),(49,'2018-08-28','A/c Receivable ','Millac Food','Rent','Service Charges','','','','',48584.25,1000,0,0,0,0,'Rent for the month of September 2018, Due date is 10th of each month Rs.1000 will be charged as penalty after the due date.',49584.25),(50,'2018-08-28','A/c Receivable ','Hussain Cane ','Rent','Electric Charges','Service Charges','','','',48338.5,5000,700,0,0,0,'Rent for the month of September 2018, Due date is 10th of each month Rs.1000 will be charged as penalty after the due date.',54038.5),(51,'2018-08-28','A/c Receivable ','Israr-ul-Haq','Rent','','','','','',35150,0,0,0,0,0,'Rent for the month of September 2018, Due date is 10th of each month Rs.1000 will be charged as penalty after the due date.',35150),(52,'2018-08-28','A/c Receivable ','FPM Petro Service ','Rent','','','','','',36960,0,0,0,0,0,'Rent for the month of September 2018, Due date is 10th of each month Rs.1000 will be charged as penalty after the due date.',36960),(53,'2018-08-28','A/c Receivable ','Kashif Mehmood-42','Rent','','','','','',145000,0,0,0,0,0,'Rent for the month of September 2018, Due date is 10th of each month Rs.1000 will be charged as penalty after the due date.',145000),(54,'2018-08-28','A/c Receivable ','Abrar Dye','Rent','','','','','',2000,0,0,0,0,0,'Rent for the month of September 2018, Due date is 10th of each month Rs.1000 will be charged as penalty after the due date.',2000),(55,'2018-08-28','A/c Receivable ','M.Hussain','Rent','','','','','',6720,0,0,0,0,0,'Rent for the month of September 2018, Due date is 10th of each month Rs.1000 will be charged as penalty after the due date.',6720),(56,'2018-08-28','A/c Receivable ','Hamza Traders','Rent','Service Charges','Balance','','','',42180,2500,4000,0,0,0,'Rent for the month of September 2018, Due date is 10th of each month Rs.1000 will be charged as penalty after the due date.',48680),(57,'2018-08-28','A/c Receivable ','Mr.Atif','Rent','','','','','',26000,0,0,0,0,0,'Rent for the month of September 2018, Due date is 10th of each month Rs.1000 will be charged as penalty after the due date.',26000),(58,'2018-08-28','A/c Receivable ','Turtex','Rent','','','','','',18751,0,0,0,0,0,'Rent for the month of September 2018, Due date is 10th of each month Rs.1000 will be charged as penalty after the due date.',18751),(59,'2018-08-28','A/c Receivable ','Turtex','Rent','Service Charges','Others','Tax','','',40000,2000,3525,-8813,0,0,'Rent for the month of September 2018, Due date is 10th of each month Rs.1000 will be charged as penalty after the due date.',36712),(60,'2018-08-28','A/c Receivable ','Mudassir','Rent','Balance','','','','',16576,-24,0,0,0,0,'Rent for the month of September 2018, Due date is 10th of each month Rs.1000 will be charged as penalty after the due date.',16552),(61,'2018-08-28','A/c Receivable ','Nafees','Rent','','','','','',13500,0,0,0,0,0,'Rent for the month of September 2018, Due date is 10th of each month Rs.1000 will be charged as penalty after the due date.',13500),(62,'2018-08-28','A/c Receivable ','Rafiq Memon','Rent','Electric Charges','Service Charges','','','',40892,5000,2000,0,0,0,'Rent for the month of September 2018, Due date is 10th of each month Rs.1000 will be charged as penalty after the due date.',47892),(63,'2018-08-28','A/c Receivable ','Al-Azam','Rent','Service Charges','Balance','','','',39442,1500,942,0,0,0,'Rent for the month of September 2018, Due date is 10th of each month Rs.1000 will be charged as penalty after the due date.',41884),(64,'2018-08-28','A/c Receivable ','Abrar Dye','Rent','','','','','',17155,0,0,0,0,0,'Rent for the month of September 2018, Due date is 10th of each month Rs.1000 will be charged as penalty after the due date.',17155),(65,'2018-08-28','A/c Receivable ','Kamran Shadman','Rent','Extra Space','','','','',8000,2000,0,0,0,0,'Rent for the month of September 2018, Due date is 10th of each month Rs.1000 will be charged as penalty after the due date.',10000),(66,'2018-09-01','A/c Receivable ','Mr. Mufaddal','Deposits','','','','','',30000,0,0,0,0,0,'Deposits for New Godown.',30000),(67,'2018-08-28','A/c Receivable ','M.Younus','Rent','Electric Charges','','','','',37000,5000,0,0,0,0,'Rent for the month of September 2018, Due date is 10th of each month. Rs.1000 will be charged as penalty after the due date.',42000),(68,'2018-08-28','A/c Receivable ','Millac Food','Rent','Electric Charges','Service Charges','','','',194122.5,9300,4000,0,0,0,'Rent for the month of September 2018, Due date is 10th of each month. Rs.1000 will be charged as penalty after the due date.',207422.5),(69,'2018-08-28','A/c Receivable ','Moiz Shabbir','Rent','Electric Charges','','','','',74934,5000,0,0,0,0,'Rent for the month of September 2018, Due date is 10th of each month Rs.1000 will be charged as penalty after the due date.',79934),(70,'2018-09-06','A/c Receivable ','Ali Imran','Deposits','Rent','','','','',39000,8670,0,0,0,0,'3 months deposit and 20 Days rent @Rs.13000 per month.',47670),(71,'2018-09-08','A/c Receivable ','Abdul Samad Jagda-New ','Deposits','','','','','',400000,0,0,0,0,0,'Deposit for New godown 6000sqft.',400000),(72,'2018-09-27','A/c Receivable ','M.Shahid Hussain','Rent','','','','','',37000,0,0,0,0,0,'Rent for the month of October 2018. Due date is 10th of the month. Rs.1000 will be charges as fine after due date.',37000),(73,'2018-09-27','A/c Receivable ','Khurram Abdul Ghaffaar','Rent','Balance','','','','',44799,4800,0,0,0,0,'Rent for the month of October 2018. Due date is 10th of the month. Rs.1000 will be charges as fine after due date.',49599),(74,'2018-09-27','A/c Receivable ','Akhlaque Ahmed','Rent','Electric Charges','','','','',52500,4000,0,0,0,0,'Rent for the month of October 2018. Due date is 10th of the month. Rs.1000 will be charges as fine after due date.',56500),(75,'2018-09-27','A/c Receivable ','Najibullah-7','Rent','','','','','',60000,0,0,0,0,0,'Rent for the month of October 2018. Due date is 10th of the month. Rs.1000 will be charges as fine after due date.',60000),(76,'2018-09-27','A/c Receivable ','Ahmed Karam Ali','Rent','Electric Charges','Service Charges','Others','Balance','',29630,5000,1222,1792,-6,0,'Rent for the month of October 2018. Due date is 10th of the month. Rs.1000 will be charges as fine after due date.',37638),(77,'2018-09-27','A/c Receivable ','Haris Ismail','Rent','','','','','',21850,0,0,0,0,0,'Rent for the month of October 2018. Due date is 10th of the month. Rs.1000 will be charges as fine after due date.',21850),(78,'2018-09-27','A/c Receivable ','Abdul Ghaffar','Rent','','','','','',110000,0,0,0,0,0,'Rent for the month of October 2018. Due date is 10th of the month. Rs.1000 will be charges as fine after due date.',110000),(79,'2018-09-27','A/c Receivable ','Zarah Traders','Rent','Electric Charges','Service Charges','','','',57750,4000,2210,0,0,0,'Rent for the month of October 2018. Due date is 10th of the month. Rs.1000 will be charges as fine after due date.',63960),(80,'2018-09-27','A/c Receivable ','Moiz Shabbir','Rent','Electric Charges','Balance','','','',74930,5000,1434,0,0,0,'Rent for the month of October 2018. Due date is 10th of the month. Rs.1000 will be charges as fine after due date.',81364),(81,'2018-09-27','A/c Receivable ','Data Enterprises','Rent','Balance','','','','',39166,9,0,0,0,0,'Rent for the month of October 2018. Due date is 10th of the month. Rs.1000 will be charges as fine after due date.',39175),(82,'2018-09-27','A/c Receivable ','Shahzad Ismail','Rent','Electric Charges','Service Charges','Parking','Balance','',32625,7000,2000,6000,-25,0,'Rent for the month of October 2018. Due date is 10th of the month. Rs.1000 will be charges as fine after due date.',47600),(83,'2018-09-27','A/c Receivable ','Waheed Memon','Rent','Electric Charges','Service Charges','Balance','','',193597,8000,8500,105582,0,0,'Rent for the month of October 2018. Due date is 10th of the month. Rs.1000 will be charges as fine after due date.',315679),(84,'2018-09-27','A/c Receivable ','Abdul Razzak','Rent','Service Charges','','','','',123000,2000,0,0,0,0,'Rent for the month of October 2018. Due date is 10th of the month. Rs.1000 will be charges as fine after due date.',125000),(85,'2018-09-27','A/c Receivable ','Safwan Sajid','Rent','','','','','',28000,0,0,0,0,0,'Rent for the month of October 2018. Due date is 10th of the month. Rs.1000 will be charges as fine after due date.',28000),(87,'2018-09-27','A/c Receivable ','Abdul Samad Jagda-29','Rent','','','','','',4000,0,0,0,0,0,'Rent for the month of October 2018. Due date is 10th of the month. Rs.1000 will be charges as fine after due date.',4000),(88,'2018-09-27','A/c Receivable ','Abdul Samad Jagda-31','Rent','','','','','',10000,0,0,0,0,0,'Rent for the month of October 2018. Due date is 10th of the month. Rs.1000 will be charges as fine after due date.',10000),(89,'2018-09-27','A/c Receivable ','New Century ','Rent','Electric Charges','','','','',57000,5000,0,0,0,0,'Rent for the month of October 2018. Due date is 10th of the month. Rs.1000 will be charges as fine after due date.',62000),(90,'2018-09-27','A/c Receivable ','Sindh Trading Corp','Rent','Others','Tax','','','',64448,3515,-3222,0,0,0,'Rent for the month of October 2018. Due date is 10th of the month. Rs.1000 will be charges as fine after due date.',64741),(91,'2018-09-27','A/c Receivable ','Kamran Shadman','Rent','Electric Charges','','','','',46000,4000,0,0,0,0,'Rent for the month of October 2018. Due date is 10th of the month. Rs.1000 will be charges as fine after due date.',50000),(92,'2018-09-27','A/c Receivable ','Millac Food','Rent','Service Charges','','','','',48584,1000,0,0,0,0,'Rent for the month of October 2018. Due date is 10th of the month. Rs.1000 will be charges as fine after due date.',49584),(93,'2018-09-27','A/c Receivable ','Hussain Cane ','Rent','Electric Charges','Service Charges','','','',48338,5000,700,0,0,0,'Rent for the month of October 2018. Due date is 10th of the month. Rs.1000 will be charges as fine after due date.',54038),(94,'2018-09-27','A/c Receivable ','Israr-ul-Haq','Rent','','','','','',35150,0,0,0,0,0,'Rent for the month of October 2018. Due date is 10th of the month. Rs.1000 will be charges as fine after due date.',35150),(95,'2018-09-27','A/c Receivable ','FPM Petro Service ','Rent','','','','','',36960,0,0,0,0,0,'Rent for the month of October 2018. Due date is 10th of the month. Rs.1000 will be charges as fine after due date.',36960),(96,'2018-09-27','A/c Receivable ','Kashif Mehmood-42','Rent','','','','','',145000,0,0,0,0,0,'Rent for the month of October 2018. Due date is 10th of the month. Rs.1000 will be charges as fine after due date.',145000),(97,'2018-09-27','A/c Receivable ','Abrar Dye','Rent','','','','','',2000,0,0,0,0,0,'Rent for the month of October 2018. Due date is 10th of the month. Rs.1000 will be charges as fine after due date.',2000),(98,'2018-09-27','A/c Receivable ','M.Hussain','Rent','','','','','',6720,0,0,0,0,0,'Rent for the month of October 2018. Due date is 10th of the month. Rs.1000 will be charges as fine after due date.',6720),(99,'2018-09-27','A/c Receivable ','Hamza Traders','Rent','Service Charges','Balance','','','',42180,2500,180,0,0,0,'Rent for the month of October 2018. Due date is 10th of the month. Rs.1000 will be charges as fine after due date.',44860),(100,'2018-09-27','A/c Receivable ','Mr.Atif','Rent','','','','','',26000,0,0,0,0,0,'Rent for the month of October 2018. Due date is 10th of the month. Rs.1000 will be charges as fine after due date.',26000),(101,'2018-09-27','A/c Receivable ','Turtex','Rent','','','','','',18751,0,0,0,0,0,'Rent for the month of October 2018. Due date is 10th of the month. Rs.1000 will be charges as fine after due date.',18751),(102,'2018-09-27','A/c Receivable ','Turtex','Rent','Service Charges','Others','Tax','','',40000,2000,3525,-8813,0,0,'Rent for the month of October 2018. Due date is 10th of the month. Rs.1000 will be charges as fine after due date.',36712),(103,'2018-09-27','A/c Receivable ','Mudassir','Rent','','','','','',16576,0,0,0,0,0,'Rent for the month of October 2018. Due date is 10th of the month. Rs.1000 will be charges as fine after due date.',16576),(104,'2018-09-27','A/c Receivable ','Nafees','Rent','','','','','',13500,0,0,0,0,0,'Rent for the month of October 2018. Due date is 10th of the month. Rs.1000 will be charges as fine after due date.',13500),(105,'2018-09-27','A/c Receivable ','Rafiq Memon','Rent','Electric Charges','Service Charges','Balance','','',40892,5000,2000,-8,0,0,'Rent for the month of October 2018. Due date is 10th of the month. Rs.1000 will be charges as fine after due date.',47884),(106,'2018-09-27','A/c Receivable ','Al-Azam','Rent','Service Charges','Balance','','','',39442,1500,884,0,0,0,'Rent for the month of October 2018. Due date is 10th of the month. Rs.1000 will be charges as fine after due date.',41826),(107,'2018-09-27','A/c Receivable ','Abrar Dye','Rent','','','','','',17155,0,0,0,0,0,'Rent for the month of October 2018. Due date is 10th of the month. Rs.1000 will be charges as fine after due date.',17155),(108,'2018-09-27','A/c Receivable ','Agha Muhammad-2','Rent','','','','','',25000,0,0,0,0,0,'Rent for the month of October 2018. Due date is 10th of the month. Rs.1000 will be charges as fine after due date.',25000),(109,'2018-09-27','A/c Receivable ','Adeel Infinty-6','Rent','Balance','','','','',50400,10000,0,0,0,0,'Rent for the month of October 2018. Due date is 10th of the month. Rs.1000 will be charges as fine after due date.',60400),(110,'2018-09-27','A/c Receivable ','M.Younus','Rent','Electric Charges','Service Charges','','','',35000,5000,5000,0,0,0,'Rent for the month of October 2018. Due date is 10th of the month. Rs.1000 will be charges as fine after due date.',45000),(111,'2018-09-27','A/c Receivable ','Orkila Pakistan','Rent','','','','','',57564,0,0,0,0,0,'Rent for the month of October 2018. Due date is 10th of the month. Rs.1000 will be charges as fine after due date.',57564),(112,'2018-09-27','A/c Receivable ','Shakeel Ahmed  ','Rent','Electric Charges','','','','',73000,4000,0,0,0,0,'Rent for the month of October 2018. Due date is 10th of the month. Rs.1000 will be charges as fine after due date.',77000),(113,'2018-09-27','A/c Receivable ','Shaikh  Afaq','Rent','Service Charges','Balance','','','',73865,3000,150,0,0,0,'Rent for the month of October 2018. Due date is 10th of the month. Rs.1000 will be charges as fine after due date.',77015),(114,'2018-09-27','A/c Receivable ','Shaikh  Afaq','Rent','','','','','',82460,0,0,0,0,0,'Rent for the month of October 2018. Due date is 10th of the month. Rs.1000 will be charges as fine after due date.',82460),(115,'2018-09-27','A/c Receivable ','M.Younus','Rent','','','','','',26000,0,0,0,0,0,'Rent for the month of October 2018. Due date is 10th of the month. Rs.1000 will be charges as fine after due date.',26000),(116,'2018-09-27','A/c Receivable ','Ali Imran','Rent','','','','','',13000,0,0,0,0,0,'Rent for the month of October 2018. Due date is 10th of the month. Rs.1000 will be charges as fine after due date.',13000),(117,'2018-09-27','A/c Receivable ','Al-Azam','Rent','Service Charges','','','','',44175,1500,0,0,0,0,'Rent for the month of October 2018. Due date is 10th of the month. Rs.1000 will be charges as fine after due date.',45675),(118,'2018-09-27','A/c Receivable ','Ilyas Scrap','Rent','','','','','',70000,0,0,0,0,0,'Rent for the month of August 2018.',70000),(119,'2018-09-28','A/c Receivable ','Younus Ahmed','Rent','','','','','',26000,0,0,0,0,0,'Rent for the month of August 2018.',26000),(120,'2018-09-27','A/c Receivable ','Abdul Samad Jagda-New ','Rent','Electric Charges','','','','',130000,8000,0,0,0,0,'Rent for the month of October 2018. Due date is 10th of the month. Rs.1000 will be charges as fine after due date.',138000),(121,'2018-09-28','A/c Receivable ','Mr. Mufaddal','Rent','','','','','',15000,0,0,0,0,0,'Rent for the month of October 2018. Due date is 10th of the month. Rs.1000 will be charges as fine after due date.',15000),(122,'2018-10-01','A/c Receivable ','Mustafa Traders','Rent','Electric Charges','','','','',400000,15000,0,0,0,0,'Rent for the month of October 2018. Due date is 10th of the month. Rs.1000 will be charges as fine after due date.',415000),(123,'2018-10-01','A/c Receivable ','Millac Food','Rent','Electric Charges','Service Charges','','','',194122.5,6880,4000,0,0,0,'Rent for the month of October 2018. Due date is 10th of the month. Rs.1000 will be charges as fine after due date. Current reading=22957 and previous reading=22785 @Rs.40',205002.5),(124,'2018-10-01','A/c Receivable ','Amjad-34','Deposits','','','','','',16000,0,0,0,0,0,'Cash received for two months deposit',16000),(125,'2018-10-02','A/c Receivable ','Pervaiz -open area','Deposits','','','','','',10000,0,0,0,0,0,'Deposit for one month for new open area rented.',10000),(126,'2018-10-03','A/c Receivable ','Muhammad Anas-02','Deposits','Rent','','','','',60000,20000,0,0,0,0,'Rent for the month of october and deposits for three months.',80000);
/*!40000 ALTER TABLE `invoice` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `payment`
--

DROP TABLE IF EXISTS `payment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `payment` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `Date` date NOT NULL,
  `chartaccount` varchar(50) NOT NULL,
  `mainaccount` varchar(50) NOT NULL,
  `subaccount` varchar(50) NOT NULL,
  `subaccount1` varchar(50) NOT NULL,
  `subaccount2` varchar(50) NOT NULL,
  `subaccount3` varchar(50) NOT NULL,
  `subaccount4` varchar(50) NOT NULL,
  `subaccount5` varchar(50) NOT NULL,
  `subaccountvalue` varchar(50) NOT NULL,
  `subaccountvalue1` varchar(50) NOT NULL,
  `subaccountvalue2` varchar(50) NOT NULL,
  `subaccountvalue3` varchar(50) NOT NULL,
  `subaccountvalue4` varchar(50) NOT NULL,
  `subaccountvalue5` varchar(50) NOT NULL,
  `by` varchar(50) NOT NULL,
  `Description` varchar(50) NOT NULL,
  `Total` int(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `payment`
--

LOCK TABLES `payment` WRITE;
/*!40000 ALTER TABLE `payment` DISABLE KEYS */;
INSERT INTO `payment` (`id`, `Date`, `chartaccount`, `mainaccount`, `subaccount`, `subaccount1`, `subaccount2`, `subaccount3`, `subaccount4`, `subaccount5`, `subaccountvalue`, `subaccountvalue1`, `subaccountvalue2`, `subaccountvalue3`, `subaccountvalue4`, `subaccountvalue5`, `by`, `Description`, `Total`) VALUES (1,'2018-08-09','Liabilities','Security Deposit','M.Ali','','','','','','100','','','','','','Petty Cash','paid to m.ali testing',100);
/*!40000 ALTER TABLE `payment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `recipt`
--

DROP TABLE IF EXISTS `recipt`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `recipt` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `Date` date NOT NULL,
  `chartaccount` varchar(50) NOT NULL,
  `mainaccount` varchar(50) NOT NULL,
  `subaccount` varchar(50) NOT NULL,
  `subaccount1` varchar(50) NOT NULL,
  `subaccount2` varchar(50) NOT NULL,
  `subaccount3` varchar(50) NOT NULL,
  `subaccount4` varchar(50) NOT NULL,
  `subaccount5` varchar(50) NOT NULL,
  `subvalue` varchar(50) NOT NULL,
  `subvalue1` varchar(50) NOT NULL,
  `subvalue2` varchar(50) NOT NULL,
  `subvalue3` varchar(50) NOT NULL,
  `subvalue4` varchar(50) NOT NULL,
  `subvalue5` varchar(50) NOT NULL,
  `by` varchar(50) NOT NULL,
  `Description` varchar(50) NOT NULL,
  `Total` int(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `recipt`
--

LOCK TABLES `recipt` WRITE;
/*!40000 ALTER TABLE `recipt` DISABLE KEYS */;
INSERT INTO `recipt` (`id`, `Date`, `chartaccount`, `mainaccount`, `subaccount`, `subaccount1`, `subaccount2`, `subaccount3`, `subaccount4`, `subaccount5`, `subvalue`, `subvalue1`, `subvalue2`, `subvalue3`, `subvalue4`, `subvalue5`, `by`, `Description`, `Total`) VALUES (1,'2018-08-09','Assets','A/c Receivable ','New Century ','','','','','','62000','','','','','','Petty Cash','Cash received.',62000),(2,'2018-08-09','Assets','A/c Receivable ','Najibullah-7','','','','','','60000','','','','','','Petty Cash','Cash Received',60000),(3,'2018-08-09','Assets','A/c Receivable ','Najibullah-7','','','','','','60000','','','','','','Petty Cash','',60000),(4,'2018-08-09','Assets','A/c Receivable ','Najibullah-7','','','','','','60000','','','','','','Petty Cash','',60000),(5,'2018-08-09','Assets','A/c Receivable ','Najibullah-7','','','','','','10000','','','','','','Petty Cash','',10000);
/*!40000 ALTER TABLE `recipt` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `records`
--

DROP TABLE IF EXISTS `records`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `records` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `Date` date NOT NULL,
  `chartaccount` varchar(50) NOT NULL,
  `mainaccount` varchar(50) NOT NULL,
  `subaccount` varchar(50) NOT NULL,
  `by` varchar(50) NOT NULL,
  `Description` varchar(50) NOT NULL,
  `Total` int(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `records`
--

LOCK TABLES `records` WRITE;
/*!40000 ALTER TABLE `records` DISABLE KEYS */;
INSERT INTO `records` (`id`, `Date`, `chartaccount`, `mainaccount`, `subaccount`, `by`, `Description`, `Total`) VALUES (1,'0000-00-00','dvsdbv','sdb','','sdbs','sdvs',1000000),(2,'2018-07-02','dfg','sdvsd','','sdfsd','sdf',1000000),(3,'2018-07-17','dvs','dfbs','','sdv','sdvs',5000),(4,'2018-07-11','sc','asa','','sdbs','sc',1000000),(5,'2018-07-10','102','1','','1','addw',600),(6,'2018-07-17','','1','','2','dfbdf',600),(7,'0000-00-00','','1','','1','komp',600),(8,'2018-07-05','','2','','2','hvj',221),(9,'2018-07-05','101','2','','2','hvj',221),(10,'0000-00-00','101','1','','1','',0),(11,'0000-00-00','101','1','','1','',0),(12,'0000-00-00','101','1','','1','',0),(13,'0000-00-00','101','1','','1','',0),(14,'0000-00-00','101','1','','1','',0),(15,'0000-00-00','icons8-edit-24.png','2','','1','fg',522);
/*!40000 ALTER TABLE `records` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `subaccount`
--

DROP TABLE IF EXISTS `subaccount`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `subaccount` (
  `subid` int(11) NOT NULL AUTO_INCREMENT,
  `accountname` varchar(50) NOT NULL,
  `amount` double NOT NULL,
  `accountid` varchar(30) NOT NULL,
  PRIMARY KEY (`subid`)
) ENGINE=InnoDB AUTO_INCREMENT=166 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `subaccount`
--

LOCK TABLES `subaccount` WRITE;
/*!40000 ALTER TABLE `subaccount` DISABLE KEYS */;
INSERT INTO `subaccount` (`subid`, `accountname`, `amount`, `accountid`) VALUES (1,'Empty',0,'1'),(2,'M.Ali',200000,'1'),(3,'M.Shahid Hussain',74000,'1'),(4,'Khurram Abdul Ghaffaar',94399,'1'),(5,'Akhlaque Ahmed',113000,'1'),(6,'Abdul Majeed',0,'1'),(7,'Kamran Shadman',120000,'1'),(8,'Abdul Ghaffar',220000,'1'),(9,'Ahmed Karam Ali',72114,'1'),(10,'China Tower',0,'1'),(11,'M.Younus',217000,'1'),(12,'Haris Ismail',43700,'1'),(13,'Zarah Traders',192199.84,'1'),(14,'Moiz Shabbir',234284,'1'),(15,'Data Enterprises',78335,'1'),(16,'Shahzad Ismail',95225,'1'),(17,'Mustafa Traders',815000,'1'),(18,'Waheed Memon',621261,'1'),(19,'Bata Paksitan',0,'1'),(20,'Abdul Razzak',239500,'1'),(21,'Empty',0,'1'),(22,'Orkila Pakistan',115128.64,'1'),(23,'Amafah',0,'1'),(24,'Safwan Sajid',56000,'1'),(25,'Shakeel Ahmed  ',146178,'1'),(26,'Shaikh  Afaq',145880,'1'),(27,'Shaikh  Afaq',165060,'1'),(28,'Younus Ahmed',26000,'1'),(29,'Younus Ahmed',0,'1'),(30,'Mehreen Corp',0,'1'),(31,'Younus Ahmed',0,'1'),(32,'New Century ',124000,'1'),(33,'Millac Food',462009.25,'1'),(34,'Shakeel Ahmed  ',0,'1'),(35,'Sindh Trading Corp',123624,'1'),(36,'Saleem Nasir',0,'1'),(37,'Millac Food',99168,'1'),(38,'Amin S. Lakdwala',0,'1'),(39,'Hussain Cane ',108076.5,'1'),(40,'Israr-ul-Haq',70300,'1'),(41,'FPM Petro Service ',73920,'1'),(42,'New Godown',0,'1'),(43,'Ilyas Scrap',270000,'1'),(44,'Ufone ',0,'1'),(45,'Empty',0,'1'),(46,'Infinity ',0,'1'),(47,'Store',0,'1'),(48,'S.B Corp',0,'1'),(49,'Abrar Dye',38310,'1'),(50,'M.Hussain',13440,'1'),(51,'Hamza Traders',237756,'1'),(52,'Mr.Atif',52000,'1'),(53,'Turtex',74214,'1'),(54,'Turtex',36712,'1'),(55,'Mudassir',33152,'1'),(56,'Nafees',27000,'1'),(57,'Rafiq Memon',95776,'1'),(58,'Infinity ',45000,'1'),(59,'Al-Azam',128501,'1'),(60,'Abrar Dye',0,'1'),(61,'Rent',6398289.39,'2'),(62,'Electric Charges',198180,'2'),(63,'Service Charges',87474,'2'),(64,'Parking',13792,'2'),(65,'Extra Space',2000,'2'),(66,'Penalty',210000,'2'),(75,'Empty',0,'3'),(76,'M.Ali',-100,'3'),(77,'M.Shahid Hussain',0,'3'),(78,'Khurram Abdul Ghaffar',0,'3'),(79,'Akhlaque Ahmad',0,'3'),(80,'Abdul Majeed',0,'3'),(81,'Kamran Shadman',0,'3'),(82,'Abdul Ghaffar',0,'3'),(83,'Ahmad Karam Ali',0,'3'),(84,'China tower ',0,'3'),(85,'M.Yousuf',0,'3'),(86,'Haris Ismail',0,'3'),(87,'Zarah Tradeas',0,'3'),(88,'Moiz Shabbir',0,'3'),(89,'Data Enterprises',0,'3'),(90,'Shahzad Ismail',0,'3'),(91,'Mustafa Traders',0,'3'),(92,'Waheed Memon',0,'3'),(93,'Bata Pakistan',0,'3'),(94,'Abdul Razzak HR',0,'3'),(95,'Empty',0,'3'),(96,'Orkila Pakistan',0,'3'),(97,'Amafah',0,'3'),(98,'Safwan Sajid ',0,'3'),(99,'Shakeel Ahmad',0,'3'),(100,'Shaikh Afaq',0,'3'),(101,'Shaikh Afaq',0,'3'),(102,'Younus Ahmad',0,'3'),(103,'Younus Ahmad',0,'3'),(104,'Mehran Corp',0,'3'),(105,'Younus Ahmad',0,'3'),(106,'New Century Ed',0,'3'),(107,'Millac Food',0,'3'),(108,'Shakeel Ahmad',0,'3'),(109,'Sindh Trading Corp',0,'3'),(110,'Saleem Nasir',0,'3'),(111,'Millac Food',0,'3'),(112,'Amin S Lakdwala',0,'3'),(113,'Hussain Cane',0,'3'),(114,'Israr Ul  Haq',0,'3'),(115,'FPM Petro Sewice',0,'3'),(116,'New Godown ',0,'3'),(117,'Ilyas Scrap',0,'3'),(118,'Ufone ',0,'3'),(119,'Empty',0,'3'),(120,'Infinity',0,'3'),(121,'Store',0,'3'),(122,'S.B Corp',0,'3'),(123,'Abrar Dye',0,'3'),(124,'M.Hussain ',0,'3'),(125,'Hamza Traders',0,'3'),(126,'MR Atif',0,'3'),(127,'Tuktex',0,'3'),(128,'Tuktex',0,'3'),(129,'Mudassir',0,'3'),(130,'Nafees',0,'3'),(131,'Rafiq Memon',0,'3'),(132,'Infinity',0,'3'),(133,'Al Azam',0,'3'),(134,'Abrar Dye Store ',0,'3'),(141,'AAD',0,'7'),(142,'UAD',0,'7'),(145,'AAD',0,'8'),(146,'UAD',0,'8'),(147,'Deposits',756000,'2'),(148,'Abdul Samad Jagda-29',13000,'1'),(149,'Abdul Samad Jagda-28',250380,'1'),(150,'Agha Muhammad-2',100000,'1'),(151,'Adeel Infinty-6',145400,'1'),(152,'Najibullah-7',50000,'1'),(153,'Kashif Mehmood-42',435000,'1'),(154,'Balance',250765,'2'),(155,'Meraj Ali',150000,'1'),(156,'Abdul Samad Jagda-31',20000,'1'),(157,'Tax',-24070,'2'),(158,'Others',15872,'2'),(159,'Mr. Mufaddal',45000,'1'),(160,'Ali Imran',60670,'1'),(161,'Abdul Samad Jagda-New ',538000,'1'),(162,'Amjad-34',16000,'1'),(163,'AMJAD-34',0,'1'),(164,'Pervaiz -open area',10000,'1'),(165,'Muhammad Anas-02',80000,'1');
/*!40000 ALTER TABLE `subaccount` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uname` varchar(50) NOT NULL,
  `pass` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` (`id`, `uname`, `pass`) VALUES (1,'admin','0101');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'choicema_accounts'
--

--
-- Dumping routines for database 'choicema_accounts'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-10-04  0:20:59
